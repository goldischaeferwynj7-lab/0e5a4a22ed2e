// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Merge profile data\n", stdout);
  return lionss_run_workload("pgo-merge");
}
