// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Resume session ticket\n", stdout);
  return lionss_run_workload("tlsResume");
}
