// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Recover stuck bus\n", stdout);
  return lionss_run_workload("I2cRecover");
}
