// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Request STUN binding"); }
int main(){
  announce();
  return lionss_run_workload("stunBinding");
}
