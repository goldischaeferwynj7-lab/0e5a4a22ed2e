// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Attach LSP client\n", stdout);
  return lionss_run_workload("nvimLsp");
}
